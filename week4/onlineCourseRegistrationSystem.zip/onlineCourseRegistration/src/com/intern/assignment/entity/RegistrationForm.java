package com.intern.assignment.entity;


import java.util.*;


public class RegistrationForm {

	private Course course;
	private Semester semester;
	
    public RegistrationForm() {
    	course=new Course();
    	semester=new Semester();
    }


}