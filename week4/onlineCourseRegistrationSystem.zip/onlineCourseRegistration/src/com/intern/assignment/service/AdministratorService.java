package com.intern.assignment.service;

import com.intern.assignment.entity.Administrator;

public class AdministratorService {
	
    public void viewStudentForm(Administrator administrator) {
       
    }

    public void confirmRegistrationForm(Administrator administrator) {
      
    }

}
