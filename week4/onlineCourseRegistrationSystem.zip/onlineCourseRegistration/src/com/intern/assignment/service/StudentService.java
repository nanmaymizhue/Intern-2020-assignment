package com.intern.assignment.service;

import com.intern.assignment.entity.Student;

public class StudentService {

    public void register(Student student) {
        
    }

   
    public void login(Student student) {
       
    }

    
    public void submitForm(Student student) {
        
    }

}
