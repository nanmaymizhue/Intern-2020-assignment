package com.intern.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.intern.test.entity.Address;
import com.intern.test.service.AddressService;

@RestController
public class AddressController {

	@Autowired
	AddressService addressService;
	
	@GetMapping(value="/address")
	public List<Address> getAddress(){
		return addressService.getAddress();
	}
	
	@PostMapping(value="/address")
	public Address addAddress(@RequestBody Address address) {
		return addressService.addAddress(address);
	}
}
