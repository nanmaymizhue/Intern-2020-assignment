package com.intern.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intern.test.entity.Address;
import com.intern.test.repository.AddressRepository;

@Service
public class AddressService {

	@Autowired
	AddressRepository addressRepository;
	
	public List<Address> getAddress(){
		return addressRepository.findAll();
	}
	
	public Address addAddress(Address address) {
		return addressRepository.save(address);
	}
}
