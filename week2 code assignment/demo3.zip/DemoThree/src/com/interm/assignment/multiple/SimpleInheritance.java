package com.interm.assignment.multiple;

class Study {
	int mark;
	void getMark() {
		mark = 100;
	}

	void showMark() {
		System.out.println("Mark : " + mark);
	}
}

interface Sport {
	String game = "Tennis";

    default void showSport() {
		
	}
}

class Student extends Study implements Sport {
	private String name;
	private int rollNo;

	public void getStudent() {
		name = "Ma Ma";
		rollNo = 20;
	}

	public void showStudent() {
		System.out.println("Name : " + name);
		System.out.println("Roll no :" + rollNo);
	}
	
	public void showSport() {
		System.out.println("Game : " + game);
		
	}
 
	
}

public class SimpleInheritance {
	public static void main (String[] args) {
		Student s = new Student();
		s.getStudent();
		s.showStudent();
		s.showSport();
		s.getMark();
		s.showMark();
	}
}