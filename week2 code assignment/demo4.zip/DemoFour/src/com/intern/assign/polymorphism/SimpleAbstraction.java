package com.intern.assign.polymorphism;

abstract class Vehicle {
	public abstract void honk();

	public void stop() {
		System.out.println("Don't honk");
	}
}

class Car extends Vehicle {
	public void honk() {
		System.out.println("Tuuk, tuuk");
	}
}

public class SimpleAbstraction {
	public static void main(String[] args) {
		Car myCar = new Car();
		myCar.honk();
		myCar.stop();
	}
}
	