package com.intern.assign.polymorphism;

class Animal {
	void eat() {
		System.out.println("eating...");
	}
}

class Dog extends Animal {
	void eat() {
		System.out.println("Dog eat bread...");
	}
}

class Cat extends Animal {
	void eat() {
		System.out.println("Cat eat rat...");
	}
}

class Lion extends Animal {
	void eat() {
		System.out.println("Lion eat meat...");
	}
}

public class SimplePolymorphism {

	public static void main(String[] args) {
		Animal d = new Dog();
		Animal c = new Cat();
		Animal l = new Lion();
		d.eat();
		c.eat();
		l.eat();
	}
}
