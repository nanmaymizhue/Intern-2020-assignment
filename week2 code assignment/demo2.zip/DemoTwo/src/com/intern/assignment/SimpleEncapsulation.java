package com.intern.assignment;

public class SimpleEncapsulation {
	public static void main(String args[]){
        Student student = new Student();
        student.setRollNo("5CS-1");
        student.setName("Mya Nandar");
        student.setAge(20);
        System.out.println("Student Roll No: " + student.getRollNo());
        System.out.println("Student Name: " + student.getName());
        System.out.println("Student Age: " + student.getAge());
   } 
}

