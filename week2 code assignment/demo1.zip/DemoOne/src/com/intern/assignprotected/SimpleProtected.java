package com.intern.assignprotected;

import com.intern.assign.Person;

public class SimpleProtected extends Person{
	public static void main(String[] args) {
		SimpleProtected sp=new SimpleProtected();
		System.out.println("ID is "+sp.id);
		sp.msg();
	}
}