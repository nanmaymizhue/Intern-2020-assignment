package com.intern.assign1;

public class Person {
	public int id=10;
	public void msg(){
		System.out.println("Hello person, this is public access modifier.");
	}  

}
