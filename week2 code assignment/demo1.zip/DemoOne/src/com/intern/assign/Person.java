package com.intern.assign;

public class Person {
	protected int id=10;
	protected void msg(){
		System.out.println("Hello person,this is protected access modifier.");
	}  

}
