package com.intern.assignprivate;


public class SimplePrivate {
	
	private static int data= 40;
	private static String myString="This is person id";
	
	public static void main(String args[]) {
		System.out.println(data);
		System.out.println(myString);
		
	}
}