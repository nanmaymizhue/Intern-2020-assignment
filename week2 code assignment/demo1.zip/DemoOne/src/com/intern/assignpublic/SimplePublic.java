package com.intern.assignpublic;
import com.intern.assign1.Person;

public class SimplePublic {
	public static void main(String args[]) {
		Person p = new Person();
		System.out.println("ID is "+p.id);
		p.msg();
	}
}