package com.intern.assigndefault;

class Person{
	int id = 10;
	void msg() {
		System.out.println("Hello person,this is default access modifier.");
	}
}  

public class SimpleDefault {
     
	public static void main(String[] args) {
		Person p=new Person();  
		   System.out.println("ID is "+p.id);
		   p.msg();
	}
}
