package com.intern.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intern.test.entity.Doctor;
import com.intern.test.repository.DoctorRepository;

@Service
public class DoctorService {

	@Autowired
	DoctorRepository doctorRepository;

	public List<Doctor> getDoctor() {
		return doctorRepository.findAll();
	}

	public Doctor addDoctor(Doctor doctor) {
		return doctorRepository.save(doctor);
	}
	
}
