package com.intern.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.intern.test.entity.Doctor;
import com.intern.test.service.DoctorService;

@RestController
public class DoctorController {

	@Autowired
	DoctorService doctorService;
	
	@GetMapping(value="/doctor")
	public List<Doctor> getDoctor(){
		return doctorService.getDoctor();
	}
	
	@PostMapping(value="/doctor")
	public Doctor addDoctor(@RequestBody Doctor doctor) {
		return doctorService.addDoctor(doctor);
	}
	
}
