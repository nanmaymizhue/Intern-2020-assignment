package com.intern.test.service;
import com.intern.test.entity.Project;
import com.intern.test.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class ProjectService {
    @Autowired
	
    ProjectRepository projectRepository;
    
    public Project save(Project project){
        return projectRepository.save(project);
    }
    
    public List<Project> findforAllId(List<Long> idList){
        return projectRepository.findByIdIn(idList);
    }
    
    public List<Project> findAll(){
        return projectRepository.findAll();
    }

	
    
	
	
}