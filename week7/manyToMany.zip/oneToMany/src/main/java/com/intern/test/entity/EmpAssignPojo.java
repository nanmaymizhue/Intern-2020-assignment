package com.intern.test.entity;

import java.util.List;

public class EmpAssignPojo {
  Long employeeId;
  List<Long> projectList;
  
  
public Long getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(Long employeeId) {
	this.employeeId = employeeId;
}
public List<Long> getProjectList() {
	return projectList;
}
public void setProjectList(List<Long> projectList) {
	this.projectList = projectList;
}
  
  
}
