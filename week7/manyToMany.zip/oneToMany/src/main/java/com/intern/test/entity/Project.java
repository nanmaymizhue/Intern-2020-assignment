package com.intern.test.entity;
import javax.persistence.*;

@Entity
@Table (name = "PROJECT")
public class Project {
   
	@Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;
    @Column (name = "PROJECT_NAME")
    String projectName;
    @Column(name = "PROJECT_DESCRIPTION")
    String projectDescription;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getProjectName() {
        return projectName;
    }
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
    public String getProjectDescription() {
        return projectDescription;
    }
    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }
}